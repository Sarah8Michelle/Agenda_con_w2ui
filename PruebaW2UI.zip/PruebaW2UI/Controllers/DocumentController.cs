﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using PruebaW2UI.Data;
using PruebaW2UI.Models;

namespace PruebaW2UI.Controllers
{
    public class DocumentController : Controller
    {
        private readonly PruebaW2uiDbContext _context;

        public DocumentController(PruebaW2uiDbContext context)
        {
            _context = context;
        }

        // GET: Document
        public IActionResult Index()
        {
            return View("Index");
        }

        [HttpPost]
        public async Task<IActionResult> CreateOrEdit(string request)
        {
            dynamic response = JsonConvert.DeserializeObject(request);

            Document input = response.ToObject<Document>();

            try
            {
                if (input.Id != 0)
                {
                    var document = _context.Documents.Include(i => i.DocumentType).Include(i => i.Person).FirstOrDefault(f => f.Id == input.Id);

                    document.Description = input.Description;
                    document.PersonId = input.PersonId;
                    document.DocumentTypeId = input.DocumentTypeId;

                    _context.Entry(document).State = EntityState.Modified;
                    await _context.SaveChangesAsync();

                    return Json(new { status = "success" });
                }

                else
                {
                    var document = new Document
                    {
                        Description = input.Description,
                        PersonId = input.PersonId,
                        DocumentTypeId = input.DocumentTypeId
                    };

                    _context.Add(document);
                    await _context.SaveChangesAsync();

                    return Json(new { status = "success" });
                }
            }

            catch
            {
                return Json(new { status = "error", message = "La operación no ha podido realizarse debido a un error en el servidor." });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Delete (int id)
        {
            try
            {
                var document = await _context.Documents.Include(i => i.DocumentType).Include(i => i.Person).SingleOrDefaultAsync(s => s.Id == id);

                if (document.Id > 0)
                {
                    _context.Remove(document);
                    await _context.SaveChangesAsync();

                    return Json(new { status = "success" });
                }

                return Json(new { status = "error", message = "Valores enviados no válidos." });
            }

            catch (Exception ex)
            {
                return Json(new { status = "error", message = $"Ha ocurrido un error al realizar la operación. {ex}" });
            }
        }

        [HttpGet]
        public JsonResult GetAllRecords()
        {
            var data = _context.Documents.Include(i => i.DocumentType).Include(i => i.Person).ToList();

            List<Document> documents = new List<Document>();

            foreach (var document in data)
            {
                documents.Add(new Document { Id = document.Id, Description = document.Description, PersonId = document.PersonId, DocumentTypeId = document.DocumentTypeId });
            }

            var output = new { status = "success", total = documents.Count, records = documents };

            return Json(output);
        }

        [HttpGet]
        public JsonResult DropdownDocumentType()
        {
            var documentTypeList = new List<DocumentType>();

            var data = _context.DocumentTypes.ToList();

            foreach(var item in data)
            {
                var list = new DocumentType
                {
                    Id = item.Id,
                    Description = item.Description
                };

                documentTypeList.Add(list);
            }

            return Json(documentTypeList);
        }

        [HttpGet]
        public JsonResult DropdownPerson()
        {
            var personList = new List<DocumentType>();

            var data = _context.DocumentTypes.ToList();

            foreach (var item in data)
            {
                var list = new DocumentType
                {
                    Id = item.Id,
                    Description = item.Description
                };

                personList.Add(list);
            }

            return Json(personList);
        }

        //var data = _context.Documents
        //        .Join(
        //        _context.People,
        //        document => document.PersonId,
        //        person => person.Id,
        //        (document, person) => new { document, person }
        //        )
        //        .Join(
        //        _context.DocumentTypes,
        //        documentWithPerson => documentWithPerson.document.DocumentTypeId,
        //        documentType => documentType.Id,
        //        (documentWithPerson, documentType) => new
        //        {
        //            documentWithPerson.document.Id,
        //            documentWithPerson.document.Description,
        //            documentWithPerson.document.PersonId,
        //            documentWithPerson.document.DocumentTypeId,
        //            FullName = documentWithPerson.person.FirstName + "" + documentWithPerson.person.LastName,
        //            DocumentTypeName = documentType.Description
        //        }
        //        )
        //        .ToList();

        // GET: Document/Details/5
        //public async Task<IActionResult> Details(int? id)
        //{
        //    if (id == null)
        //    {
        //        return NotFound();
        //    }

        //    var document = await _context.Documents
        //        .Include(d => d.DocumentType)
        //        .Include(d => d.Person)
        //        .FirstOrDefaultAsync(m => m.Id == id);
        //    if (document == null)
        //    {
        //        return NotFound();
        //    }

        //    return View(document);
        //}

        //// GET: Document/Create
        //public IActionResult Create()
        //{
        //    ViewData["DocumentTypeId"] = new SelectList(_context.DocumentTypes, "Id", "Description");
        //    ViewData["PersonId"] = new SelectList(_context.People, "Id", "FirstName");
        //    return View();
        //}

        //// POST: Document/Create
        //// To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        //// more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Create([Bind("Id,PersonId,DocumentTypeId,Description")] Document document)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _context.Add(document);
        //        await _context.SaveChangesAsync();
        //        return RedirectToAction(nameof(Index));
        //    }
        //    ViewData["DocumentTypeId"] = new SelectList(_context.DocumentTypes, "Id", "Description", document.DocumentTypeId);
        //    ViewData["PersonId"] = new SelectList(_context.People, "Id", "FirstName", document.PersonId);
        //    return View(document);
        //}

        //// GET: Document/Edit/5
        //public async Task<IActionResult> Edit(int? id)
        //{
        //    if (id == null)
        //    {
        //        return NotFound();
        //    }

        //    var document = await _context.Documents.FindAsync(id);
        //    if (document == null)
        //    {
        //        return NotFound();
        //    }
        //    ViewData["DocumentTypeId"] = new SelectList(_context.DocumentTypes, "Id", "Description", document.DocumentTypeId);
        //    ViewData["PersonId"] = new SelectList(_context.People, "Id", "FirstName", document.PersonId);
        //    return View(document);
        //}

        //// POST: Document/Edit/5
        //// To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        //// more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Edit(int id, [Bind("Id,PersonId,DocumentTypeId,Description")] Document document)
        //{
        //    if (id != document.Id)
        //    {
        //        return NotFound();
        //    }

        //    if (ModelState.IsValid)
        //    {
        //        try
        //        {
        //            _context.Update(document);
        //            await _context.SaveChangesAsync();
        //        }
        //        catch (DbUpdateConcurrencyException)
        //        {
        //            if (!DocumentExists(document.Id))
        //            {
        //                return NotFound();
        //            }
        //            else
        //            {
        //                throw;
        //            }
        //        }
        //        return RedirectToAction(nameof(Index));
        //    }
        //    ViewData["DocumentTypeId"] = new SelectList(_context.DocumentTypes, "Id", "Description", document.DocumentTypeId);
        //    ViewData["PersonId"] = new SelectList(_context.People, "Id", "FirstName", document.PersonId);
        //    return View(document);
        //}

        //// GET: Document/Delete/5
        //public async Task<IActionResult> Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return NotFound();
        //    }

        //    var document = await _context.Documents
        //        .Include(d => d.DocumentType)
        //        .Include(d => d.Person)
        //        .FirstOrDefaultAsync(m => m.Id == id);
        //    if (document == null)
        //    {
        //        return NotFound();
        //    }

        //    return View(document);
        //}

        //// POST: Document/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> DeleteConfirmed(int id)
        //{
        //    var document = await _context.Documents.FindAsync(id);
        //    _context.Documents.Remove(document);
        //    await _context.SaveChangesAsync();
        //    return RedirectToAction(nameof(Index));
        //}

        //private bool DocumentExists(int id)
        //{
        //    return _context.Documents.Any(e => e.Id == id);
        //}
    }
}
